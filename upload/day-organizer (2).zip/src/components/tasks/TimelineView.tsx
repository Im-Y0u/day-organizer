'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { useTaskStore, Task, formatTime, URGENCY_COLORS } from '@/store/taskStore'
import { Card } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { cn } from '@/lib/utils'
import { GripVertical } from 'lucide-react'

interface TimelineViewProps {
  selectedDate: string
  onEditTask: (task: Task) => void
}

export function TimelineView({ selectedDate, onEditTask }: TimelineViewProps) {
  const { getTasksForDateWithDaily, toggleComplete, updateTask } = useTaskStore()
  const tasks = getTasksForDateWithDaily(selectedDate)
  const [currentTime, setCurrentTime] = useState(new Date())
  const [dragInfo, setDragInfo] = useState<{
    taskId: string
    mode: 'move' | 'resize-top' | 'resize-bottom'
    startMouseY: number
    originalStartMins: number
    originalEndMins: number
  } | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  
  // Update current time every minute
  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(new Date()), 60000)
    return () => clearInterval(interval)
  }, [])
  
  // Timeline config - 6 AM to 10 PM
  const START_HOUR = 6
  const END_HOUR = 22
  const HOUR_HEIGHT = 72 // pixels per hour
  const MINUTE_HEIGHT = HOUR_HEIGHT / 60
  
  // Convert time string to minutes from start of timeline
  const timeToMinutes = (time: string): number => {
    const [h, m] = time.split(':').map(Number)
    return (h - START_HOUR) * 60 + m
  }
  
  // Convert minutes to time string, snapped to 5 min intervals
  const minutesToTime = (mins: number): string => {
    const totalMins = Math.max(0, Math.min((END_HOUR - START_HOUR) * 60, mins))
    const snapped = Math.round(totalMins / 5) * 5
    const h = Math.floor(snapped / 60) + START_HOUR
    const m = snapped % 60
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`
  }
  
  // Get task position
  const getTaskPosition = (task: Task) => {
    const startMins = timeToMinutes(task.startTime)
    const endMins = timeToMinutes(task.endTime)
    const top = startMins * MINUTE_HEIGHT
    const height = Math.max(28, (endMins - startMins) * MINUTE_HEIGHT)
    return { top, height }
  }
  
  // Start drag
  const startDrag = (e: React.MouseEvent, task: Task, mode: 'move' | 'resize-top' | 'resize-bottom') => {
    e.preventDefault()
    e.stopPropagation()
    setDragInfo({
      taskId: task.id,
      mode,
      startMouseY: e.clientY,
      originalStartMins: timeToMinutes(task.startTime),
      originalEndMins: timeToMinutes(task.endTime),
    })
  }
  
  // Handle drag
  useEffect(() => {
    if (!dragInfo) return
    
    const onMouseMove = (e: MouseEvent) => {
      const deltaY = e.clientY - dragInfo.startMouseY
      const deltaMins = Math.round((deltaY / HOUR_HEIGHT) * 60 / 5) * 5
      
      let newStart = dragInfo.originalStartMins
      let newEnd = dragInfo.originalEndMins
      const duration = dragInfo.originalEndMins - dragInfo.originalStartMins
      const maxMins = (END_HOUR - START_HOUR) * 60
      
      if (dragInfo.mode === 'move') {
        newStart = Math.max(0, Math.min(maxMins - duration, dragInfo.originalStartMins + deltaMins))
        newEnd = newStart + duration
      } else if (dragInfo.mode === 'resize-top') {
        newStart = Math.max(0, Math.min(dragInfo.originalEndMins - 15, dragInfo.originalStartMins + deltaMins))
      } else {
        newEnd = Math.max(dragInfo.originalStartMins + 15, Math.min(maxMins, dragInfo.originalEndMins + deltaMins))
      }
      
      updateTask(dragInfo.taskId, {
        startTime: minutesToTime(newStart),
        endTime: minutesToTime(newEnd)
      })
    }
    
    const onMouseUp = () => setDragInfo(null)
    
    document.addEventListener('mousemove', onMouseMove)
    document.addEventListener('mouseup', onMouseUp)
    return () => {
      document.removeEventListener('mousemove', onMouseMove)
      document.removeEventListener('mouseup', onMouseUp)
    }
  }, [dragInfo, HOUR_HEIGHT, updateTask])
  
  // Current time line
  const getCurrentTimePos = () => {
    const today = new Date().toISOString().split('T')[0]
    if (selectedDate !== today) return null
    const h = currentTime.getHours()
    const m = currentTime.getMinutes()
    if (h < START_HOUR || h >= END_HOUR) return null
    return (h - START_HOUR) * HOUR_HEIGHT + (m / 60) * HOUR_HEIGHT
  }
  
  const currentTimePos = getCurrentTimePos()
  const hours = Array.from({ length: END_HOUR - START_HOUR + 1 }, (_, i) => START_HOUR + i)
  
  return (
    <div className="space-y-3">
      {/* Instructions */}
      <div className="flex items-center justify-center gap-4 text-xs text-slate-400 bg-slate-800/50 rounded-lg py-2 px-4">
        <GripVertical className="w-3.5 h-3.5" />
        <span>Drag to move • Drag edges to resize</span>
      </div>
      
      {/* Timeline */}
      <div className="flex rounded-xl border border-slate-700 bg-slate-800/30 overflow-hidden">
        {/* Time labels */}
        <div className="w-16 flex-shrink-0 border-r border-slate-700 bg-slate-800/50">
          {hours.map((hour, i) => (
            <div
              key={hour}
              className="flex items-start justify-end pr-3 pt-1"
              style={{ height: i === hours.length - 1 ? 0 : HOUR_HEIGHT }}
            >
              {i < hours.length - 1 && (
                <span className={cn(
                  "text-xs font-medium tabular-nums",
                  selectedDate === new Date().toISOString().split('T')[0] && hour === new Date().getHours()
                    ? "text-violet-400"
                    : "text-slate-400"
                )}>
                  {hour === 12 ? '12 PM' : hour > 12 ? `${hour - 12} PM` : `${hour} AM`}
                </span>
              )}
            </div>
          ))}
        </div>
        
        {/* Grid and tasks */}
        <div 
          ref={scrollRef}
          className="flex-1 relative"
          style={{ height: (END_HOUR - START_HOUR) * HOUR_HEIGHT }}
        >
          {/* Hour grid lines */}
          {hours.slice(0, -1).map((hour) => (
            <div
              key={hour}
              className={cn(
                "border-t border-slate-700/60",
                selectedDate === new Date().toISOString().split('T')[0] && hour === new Date().getHours() && "bg-violet-500/10"
              )}
              style={{ height: HOUR_HEIGHT }}
            />
          ))}
          
          {/* Current time line */}
          {currentTimePos !== null && (
            <div
              className="absolute left-0 right-0 flex items-center z-20"
              style={{ top: currentTimePos }}
            >
              <span className="absolute -left-1 -translate-x-full pr-2 text-[10px] font-bold text-rose-400 tabular-nums whitespace-nowrap">
                {currentTime.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}
              </span>
              <div className="w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0" />
              <div className="flex-1 h-0.5 bg-rose-500" />
            </div>
          )}
          
          {/* Tasks */}
          {tasks.map((task) => {
            const { top, height } = getTaskPosition(task)
            const urgency = URGENCY_COLORS[task.urgency || 'medium']
            const isDragging = dragInfo?.taskId === task.id
            
            return (
              <Card
                key={task.id}
                className={cn(
                  "absolute left-2 right-2 overflow-hidden group",
                  "border-l-4 rounded-lg transition-shadow",
                  urgency.border,
                  task.completed && "opacity-50",
                  isDragging && "ring-2 ring-violet-400 shadow-xl z-10"
                )}
                style={{ top, height }}
                onClick={() => !dragInfo && onEditTask(task)}
              >
                {/* Top resize handle */}
                <div
                  className="absolute top-0 left-0 right-0 h-3 cursor-ns-resize z-20"
                  onMouseDown={(e) => startDrag(e, task, 'resize-top')}
                />
                
                {/* Content */}
                <div className={cn("h-full flex items-center", urgency.bg, "px-2 py-1")}>
                  {/* Move handle */}
                  <div
                    className="flex-1 flex items-center gap-2 cursor-move min-w-0"
                    onMouseDown={(e) => startDrag(e, task, 'move')}
                  >
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={() => toggleComplete(task.id)}
                      onClick={(e) => e.stopPropagation()}
                      className="shrink-0 border-slate-400"
                    />
                    <span className={cn(
                      "font-medium truncate flex-1 min-w-0",
                      task.completed && "line-through text-slate-400"
                    )}>
                      {task.title}
                    </span>
                    <span className="text-xs text-slate-400 tabular-nums shrink-0">
                      {formatTime(task.startTime)}-{formatTime(task.endTime)}
                    </span>
                  </div>
                </div>
                
                {/* Bottom resize handle */}
                <div
                  className="absolute bottom-0 left-0 right-0 h-3 cursor-ns-resize z-20"
                  onMouseDown={(e) => startDrag(e, task, 'resize-bottom')}
                />
              </Card>
            )
          })}
        </div>
      </div>
      
      {/* Empty state */}
      {tasks.length === 0 && (
        <div className="text-center py-12 text-slate-500 bg-slate-800/30 rounded-xl border border-slate-700">
          <GripVertical className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p className="font-medium">No tasks scheduled</p>
          <p className="text-sm mt-1">Add a task to see it on the timeline</p>
        </div>
      )}
    </div>
  )
}
