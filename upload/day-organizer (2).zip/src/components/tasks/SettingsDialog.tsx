'use client'

import { useState } from 'react'
import { useSettingsStore, sendTelegramNotification } from '@/store/settingsStore'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Bell, Send, CheckCircle2, XCircle, Loader2, Volume2, VolumeX, Play } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { soundManager } from '@/lib/sounds'

interface SettingsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const { 
    telegramWebhookUrl, 
    setTelegramWebhookUrl,
    notificationsEnabled,
    setNotificationsEnabled,
    notifyMinutesBefore,
    setNotifyMinutesBefore,
    soundEnabled,
    setSoundEnabled
  } = useSettingsStore()
  
  const [testStatus, setTestStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  
  const handleTestNotification = async () => {
    if (!telegramWebhookUrl) return
    
    setTestStatus('loading')
    const success = await sendTelegramNotification(
      telegramWebhookUrl,
      'Test Notification',
      'Now',
      'Soon'
    )
    setTestStatus(success ? 'success' : 'error')
    
    setTimeout(() => setTestStatus('idle'), 3000)
  }
  
  const handleTestSound = () => {
    soundManager.play('notification')
  }
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[450px] bg-slate-900 border-slate-700 text-white">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Settings
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Sound Settings */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
              Sound Alerts
            </h3>
            
            <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50 border border-slate-700">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Enable Sounds</Label>
                <p className="text-xs text-slate-400">
                  Play sounds for notifications and completions
                </p>
              </div>
              <Switch
                checked={soundEnabled}
                onCheckedChange={(enabled) => {
                  setSoundEnabled(enabled)
                  soundManager.setEnabled(enabled)
                }}
              />
            </div>
            
            {soundEnabled && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleTestSound}
                className="w-full border-slate-600 hover:bg-slate-800"
              >
                <Play className="w-4 h-4 mr-2" />
                Test Sound
              </Button>
            )}
          </div>
          
          {/* Divider */}
          <div className="border-t border-slate-700" />
          
          {/* Telegram Webhook */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
              <Send className="w-4 h-4 text-sky-400" />
              Telegram Notifications
              <Badge variant="outline" className="text-xs ml-auto">
                Optional
              </Badge>
            </h3>
            
            <div className="space-y-2">
              <Label className="text-sm font-medium">Webhook URL</Label>
              <Input
                placeholder="https://api.telegram.org/botYOUR_BOT_TOKEN/sendMessage?chat_id=YOUR_CHAT_ID"
                value={telegramWebhookUrl}
                onChange={(e) => setTelegramWebhookUrl(e.target.value)}
                className="bg-slate-800 border-slate-600 font-mono text-xs"
              />
              <p className="text-xs text-slate-500">
                Create a bot via @BotFather, get your bot token and chat ID
              </p>
            </div>
            
            {/* Test Notification */}
            {telegramWebhookUrl && (
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleTestNotification}
                  disabled={testStatus === 'loading'}
                  className="flex items-center gap-2 border-slate-600 hover:bg-slate-800"
                >
                  {testStatus === 'loading' ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  Test
                </Button>
                
                {testStatus === 'success' && (
                  <span className="flex items-center gap-1 text-sm text-emerald-400">
                    <CheckCircle2 className="w-4 h-4" />
                    Sent!
                  </span>
                )}
                {testStatus === 'error' && (
                  <span className="flex items-center gap-1 text-sm text-rose-400">
                    <XCircle className="w-4 h-4" />
                    Failed
                  </span>
                )}
              </div>
            )}
            
            {/* Enable Notifications */}
            <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50 border border-slate-700">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Enable Notifications</Label>
                <p className="text-xs text-slate-400">
                  Get notified before tasks start
                </p>
              </div>
              <Switch
                checked={notificationsEnabled}
                onCheckedChange={setNotificationsEnabled}
                disabled={!telegramWebhookUrl}
              />
            </div>
            
            {/* Notify Before */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Notify Before</Label>
              <Select 
                value={notifyMinutesBefore.toString()} 
                onValueChange={(v) => setNotifyMinutesBefore(parseInt(v))}
                disabled={!notificationsEnabled}
              >
                <SelectTrigger className="bg-slate-800 border-slate-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 minute before</SelectItem>
                  <SelectItem value="5">5 minutes before</SelectItem>
                  <SelectItem value="10">10 minutes before</SelectItem>
                  <SelectItem value="15">15 minutes before</SelectItem>
                  <SelectItem value="30">30 minutes before</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            onClick={() => onOpenChange(false)} 
            className="w-full bg-violet-500 hover:bg-violet-600"
          >
            Done
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
