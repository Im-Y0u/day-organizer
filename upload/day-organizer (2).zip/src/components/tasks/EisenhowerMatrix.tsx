'use client'

import { Task, useTaskStore, formatTime, URGENCY_COLORS, URGENCY_LABELS } from '@/store/taskStore'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { Button } from '@/components/ui/button'
import { 
  Flame, Clock, Trash2, AlertTriangle, 
  Calendar, Zap, MinusCircle
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface EisenhowerMatrixProps {
  selectedDate: string
  onEditTask: (task: Task) => void
}

export function EisenhowerMatrix({ selectedDate, onEditTask }: EisenhowerMatrixProps) {
  const { getEisenhowerTasks, toggleComplete, deleteTask } = useTaskStore()
  const quadrants = getEisenhowerTasks(selectedDate)
  
  const quadrantConfig = {
    doNow: {
      title: 'Do Now',
      subtitle: 'Urgent - Act immediately',
      icon: Flame,
      color: 'from-rose-500 to-orange-500',
      bg: 'bg-rose-500/10',
      border: 'border-rose-500/30',
      text: 'text-rose-400',
      description: 'Drop everything and handle these',
    },
    doSoon: {
      title: 'Do Soon',
      subtitle: 'High Priority - Plan time today',
      icon: AlertTriangle,
      color: 'from-amber-500 to-yellow-500',
      bg: 'bg-amber-500/10',
      border: 'border-amber-500/30',
      text: 'text-amber-400',
      description: 'Schedule these for later today',
    },
    canWait: {
      title: 'Can Wait',
      subtitle: 'Medium Priority - Flexible',
      icon: Calendar,
      color: 'from-sky-500 to-cyan-500',
      bg: 'bg-sky-500/10',
      border: 'border-sky-500/30',
      text: 'text-sky-400',
      description: 'These can be rescheduled if needed',
    },
    whenever: {
      title: 'Whenever',
      subtitle: 'Low Priority - Optional',
      icon: Zap,
      color: 'from-emerald-500 to-teal-500',
      bg: 'bg-emerald-500/10',
      border: 'border-emerald-500/30',
      text: 'text-emerald-400',
      description: 'Nice to have, not essential',
    },
  }
  
  const totalTasks = Object.values(quadrants).flat().length
  
  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
            <MinusCircle className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="font-semibold">Priority Matrix</h3>
            <p className="text-xs text-slate-400">{totalTasks} tasks sorted by urgency</p>
          </div>
        </div>
      </div>
      
      {/* Matrix Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {(Object.keys(quadrants) as Array<keyof typeof quadrants>).map((key) => {
          const config = quadrantConfig[key]
          const tasks = quadrants[key]
          const Icon = config.icon
          
          return (
            <Card 
              key={key}
              className={cn(
                "border-2 bg-slate-800/50",
                config.border
              )}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <div className={cn(
                    "w-8 h-8 rounded-lg flex items-center justify-center",
                    config.bg
                  )}>
                    <Icon className={cn("w-4 h-4", config.text)} />
                  </div>
                  <div>
                    <CardTitle className="text-base">{config.title}</CardTitle>
                    <p className="text-xs text-slate-500">{config.subtitle}</p>
                  </div>
                  <Badge variant="outline" className={cn("ml-auto", config.border, config.text)}>
                    {tasks.length}
                  </Badge>
                </div>
                <p className="text-xs text-slate-500 mt-2">{config.description}</p>
              </CardHeader>
              <CardContent>
                {tasks.length === 0 ? (
                  <div className="text-center py-6 text-slate-500">
                    <Icon className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">No tasks</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {tasks.map((task) => {
                      const urgencyStyle = URGENCY_COLORS[task.urgency]
                      
                      return (
                        <div 
                          key={task.id}
                          onClick={() => onEditTask(task)}
                          className={cn(
                            "p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md",
                            config.bg,
                            config.border,
                            task.completed && "opacity-50"
                          )}
                        >
                          <div className="flex items-start gap-2">
                            <Checkbox
                              checked={task.completed}
                              onCheckedChange={() => toggleComplete(task.id)}
                              onClick={(e) => e.stopPropagation()}
                              className="mt-0.5"
                            />
                            <div className="flex-1 min-w-0">
                              <div className={cn(
                                "text-sm font-medium truncate",
                                task.completed && "line-through text-slate-400"
                              )}>
                                {task.title}
                              </div>
                              <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                                <Clock className="w-3 h-3" />
                                <span>{formatTime(task.startTime)}</span>
                                <span className={cn("px-1.5 py-0.5 rounded text-[10px]", urgencyStyle.badge)}>
                                  {URGENCY_LABELS[task.urgency]}
                                </span>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 text-slate-500 hover:text-rose-400"
                              onClick={(e) => {
                                e.stopPropagation()
                                deleteTask(task.id)
                              }}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>
      
      {/* Legend */}
      <Card className="bg-slate-800/30 border-slate-700">
        <CardContent className="p-4">
          <div className="flex items-center justify-center gap-6 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-rose-400" />
              <span>Urgent = Needs immediate action</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-sky-400" />
              <span>Focus on top-left first</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
