'use client'

import { useEffect, useRef } from 'react'
import { useTaskStore, formatTime } from '@/store/taskStore'
import { useSettingsStore, sendTelegramNotification } from '@/store/settingsStore'

export function useNotifications() {
  const { getUpcomingTasks, markNotified } = useTaskStore()
  const { telegramWebhookUrl, notificationsEnabled, notifyMinutesBefore } = useSettingsStore()
  const notifiedRef = useRef<Set<string>>(new Set())
  
  useEffect(() => {
    if (!notificationsEnabled || !telegramWebhookUrl) return
    
    const checkAndNotify = async () => {
      const upcomingTasks = getUpcomingTasks(notifyMinutesBefore)
      
      for (const task of upcomingTasks) {
        // Skip if already notified in this session
        if (notifiedRef.current.has(task.id)) continue
        
        // Send notification
        const success = await sendTelegramNotification(
          telegramWebhookUrl,
          task.title,
          formatTime(task.startTime),
          formatTime(task.endTime)
        )
        
        if (success) {
          notifiedRef.current.add(task.id)
          markNotified(task.id)
        }
      }
    }
    
    // Check immediately
    checkAndNotify()
    
    // Check every 30 seconds
    const interval = setInterval(checkAndNotify, 30000)
    
    return () => clearInterval(interval)
  }, [notificationsEnabled, telegramWebhookUrl, notifyMinutesBefore, getUpcomingTasks, markNotified])
  
  return null
}
