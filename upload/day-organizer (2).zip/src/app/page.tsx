'use client'

import { useState, useEffect, useRef, useSyncExternalStore, useCallback } from 'react'
import { format, addDays, subDays } from 'date-fns'
import { 
  ChevronLeft, ChevronRight, Plus, Calendar as CalendarIcon, Repeat, 
  CheckCircle2, Settings, Moon, Sun, Zap, BarChart3, 
  Clock, Flame, Sparkles, LayoutList, Grid3X3, Undo2, Redo2
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { 
  DndContext, 
  closestCenter, 
  KeyboardSensor, 
  PointerSensor, 
  useSensor, 
  useSensors,
  DragEndEvent
} from '@dnd-kit/core'
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable'
import { useTaskStore, getTodayDate, formatDate, Task } from '@/store/taskStore'
import { useSettingsStore } from '@/store/settingsStore'
import { useStatsStore } from '@/store/statsStore'
import { useHistoryStore, useUndoRedo } from '@/store/historyStore'
import { TaskForm } from '@/components/tasks/TaskForm'
import { DailyTaskForm } from '@/components/tasks/DailyTaskForm'
import { ProgressBar } from '@/components/tasks/ProgressBar'
import { SettingsDialog } from '@/components/tasks/SettingsDialog'
import { DailySummary } from '@/components/tasks/DailySummary'
import { CompletionStats } from '@/components/tasks/CompletionStats'
import { TimelineView } from '@/components/tasks/TimelineView'
import { EisenhowerMatrix } from '@/components/tasks/EisenhowerMatrix'
import { SortableTaskCard } from '@/components/tasks/SortableTaskCard'
import { useNotifications } from '@/hooks/useNotifications'
import { soundManager } from '@/lib/sounds'
import { cn } from '@/lib/utils'

// Hydration helper
const emptySubscribe = () => () => {}
const getSnapshot = () => true
const getServerSnapshot = () => false

type ViewMode = 'schedule' | 'timeline' | 'matrix'

export default function Home() {
  const [selectedDate, setSelectedDate] = useState(getTodayDate())
  const [isTaskFormOpen, setIsTaskFormOpen] = useState(false)
  const [isDailyFormOpen, setIsDailyFormOpen] = useState(false)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [isSummaryOpen, setIsSummaryOpen] = useState(false)
  const [isStatsOpen, setIsStatsOpen] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | null>(null)
  const [editingDailyTask, setEditingDailyTask] = useState<Task | null>(null)
  const [viewMode, setViewMode] = useState<ViewMode>('schedule')
  const [activeTab, setActiveTab] = useState('schedule')
  const mountedRef = useRef(false)
  const prevCompletedRef = useRef<number>(0)
  
  // Use sync external store for hydration
  const hydrated = useSyncExternalStore(emptySubscribe, getSnapshot, getServerSnapshot)
  
  const { 
    getTasksForDateWithDaily, 
    getDailyTasks, 
    getProgressForDate,
    reorderTasks,
    toggleComplete,
    tasks: allTasks,
    restoreTasks
  } = useTaskStore()
  const { theme, setTheme, notificationsEnabled, soundEnabled } = useSettingsStore()
  const { currentStreak, longestStreak, updateDayStats } = useStatsStore()
  const { canUndo, canRedo, undo, redo, pushHistory } = useHistoryStore()
  
  // Initialize notifications
  useNotifications()
  
  // Undo/Redo handlers
  const handleUndo = useCallback(() => {
    const entry = undo()
    if (entry) {
      restoreTasks(entry.tasksBefore)
      if (soundEnabled) soundManager.play('notification')
    }
  }, [undo, restoreTasks, soundEnabled])
  
  const handleRedo = useCallback(() => {
    const entry = redo()
    if (entry) {
      restoreTasks(entry.tasksAfter)
      if (soundEnabled) soundManager.play('notification')
    }
  }, [redo, restoreTasks, soundEnabled])
  
  // Keyboard shortcuts for undo/redo
  useUndoRedo(handleUndo, handleRedo)
  
  // Handle theme and sound
  useEffect(() => {
    mountedRef.current = true
    soundManager.setEnabled(soundEnabled)
  }, [soundEnabled])
  
  useEffect(() => {
    if (mountedRef.current) {
      document.documentElement.classList.toggle('dark', theme === 'dark')
    }
  }, [theme])
  
  const tasks = getTasksForDateWithDaily(selectedDate)
  const dailyTasks = getDailyTasks()
  const progress = getProgressForDate(selectedDate)
  
  // Play sound when task completed
  useEffect(() => {
    if (progress.completed > prevCompletedRef.current && soundEnabled) {
      soundManager.play('complete')
    }
    prevCompletedRef.current = progress.completed
  }, [progress.completed, soundEnabled])
  
  // Update stats when tasks change
  useEffect(() => {
    if (selectedDate === getTodayDate()) {
      updateDayStats(selectedDate, {
        totalTasks: progress.total,
        completedTasks: progress.completed,
      })
    }
  }, [selectedDate, progress.total, progress.completed, updateDayStats])
  
  // Separate quick tasks
  const quickTasks = tasks.filter(t => t.isQuick)
  const regularTasks = tasks.filter(t => !t.isQuick)
  const taskIds = tasks.map(t => t.id)
  
  // DnD sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  )
  
  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event
    
    if (over && active.id !== over.id) {
      const oldIndex = tasks.findIndex(t => t.id === active.id)
      const newIndex = tasks.findIndex(t => t.id === over.id)
      
      const newOrder = arrayMove(taskIds, oldIndex, newIndex)
      reorderTasks(selectedDate, newOrder)
    }
  }
  
  const navigateDate = (direction: 'prev' | 'next') => {
    const current = new Date(selectedDate + 'T00:00:00')
    const newDate = direction === 'next' ? addDays(current, 1) : subDays(current, 1)
    setSelectedDate(newDate.toISOString().split('T')[0])
  }
  
  const goToToday = () => {
    setSelectedDate(getTodayDate())
  }
  
  const isToday = selectedDate === getTodayDate()
  
  const handleEditTask = (task: Task) => {
    setEditingTask(task)
    setIsTaskFormOpen(true)
  }
  
  const handleEditDailyTask = (task: Task) => {
    setEditingDailyTask(task)
    setIsDailyFormOpen(true)
  }
  
  // Group tasks by time period for timeline view
  const groupedTasks = regularTasks.reduce((acc, task) => {
    const hour = parseInt(task.startTime.split(':')[0])
    let period = 'Morning'
    if (hour >= 12 && hour < 17) period = 'Afternoon'
    else if (hour >= 17) period = 'Evening'
    
    if (!acc[period]) acc[period] = []
    acc[period].push(task)
    return acc
  }, {} as Record<string, typeof tasks>)
  
  if (!hydrated) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Header */}
        <header className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
                Day Organizer
              </h1>
              <p className="text-sm text-slate-400 mt-0.5">Plan your day, stay productive</p>
            </div>
            <div className="flex items-center gap-2">
              {/* Undo/Redo Buttons */}
              <div className="flex items-center gap-1 mr-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleUndo}
                  disabled={!canUndo()}
                  className="h-8 w-8 text-slate-400 hover:text-white hover:bg-white/10 disabled:opacity-30"
                  title="Undo (Ctrl+Z)"
                >
                  <Undo2 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleRedo}
                  disabled={!canRedo()}
                  className="h-8 w-8 text-slate-400 hover:text-white hover:bg-white/10 disabled:opacity-30"
                  title="Redo (Ctrl+Y)"
                >
                  <Redo2 className="h-4 w-4" />
                </Button>
              </div>
              
              {/* Streak Badge */}
              {currentStreak > 0 && (
                <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30 gap-1">
                  <Flame className="w-3 h-3" />
                  {currentStreak}
                </Badge>
              )}
              
              {/* Stats Button */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsStatsOpen(true)}
                className="text-slate-400 hover:text-white hover:bg-white/10"
              >
                <BarChart3 className="h-5 w-5" />
              </Button>
              
              {notificationsEnabled && (
                <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-xs">
                  <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full mr-1.5 animate-pulse" />
                  On
                </Badge>
              )}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="text-slate-400 hover:text-white hover:bg-white/10"
              >
                {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsSettingsOpen(true)}
                className="text-slate-400 hover:text-white hover:bg-white/10"
              >
                <Settings className="h-5 w-5" />
              </Button>
            </div>
          </div>
          
          {/* View Mode Switcher */}
          <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-2">
            <Button
              variant={viewMode === 'schedule' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('schedule')}
              className={cn(
                "gap-2 shrink-0",
                viewMode === 'schedule' && "bg-violet-500 hover:bg-violet-600"
              )}
            >
              <LayoutList className="w-4 h-4" />
              Schedule
            </Button>
            <Button
              variant={viewMode === 'timeline' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('timeline')}
              className={cn(
                "gap-2 shrink-0",
                viewMode === 'timeline' && "bg-violet-500 hover:bg-violet-600"
              )}
            >
              <Clock className="w-4 h-4" />
              Timeline
            </Button>

            <Button
              variant={viewMode === 'matrix' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('matrix')}
              className={cn(
                "gap-2 shrink-0",
                viewMode === 'matrix' && "bg-violet-500 hover:bg-violet-600"
              )}
            >
              <Grid3X3 className="w-4 h-4" />
              Matrix
            </Button>
          </div>
          
          {/* Date Navigation */}
          <div className="flex items-center justify-between bg-slate-800/50 backdrop-blur-sm rounded-2xl p-4 border border-slate-700/50 shadow-xl">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigateDate('prev')}
                className="h-10 w-10 text-slate-400 hover:text-white hover:bg-white/10"
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              
              <button
                onClick={goToToday}
                className="text-center px-4 py-1 rounded-xl hover:bg-white/5 transition-colors"
              >
                <div className={cn(
                  "text-lg font-bold",
                  isToday ? "text-violet-400" : "text-white"
                )}>
                  {formatDate(selectedDate)}
                </div>
                {!isToday && (
                  <div className="text-xs text-slate-500 mt-0.5">
                    {format(new Date(selectedDate + 'T00:00:00'), 'MMM d, yyyy')}
                  </div>
                )}
              </button>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigateDate('next')}
                className="h-10 w-10 text-slate-400 hover:text-white hover:bg-white/10"
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>
          
          {/* Progress Bar - Only show for today and not in matrix view */}
          {isToday && viewMode !== 'matrix' && (
            <div className="mt-4 bg-slate-800/50 backdrop-blur-sm rounded-2xl p-4 border border-slate-700/50 shadow-xl">
              <div className="flex items-center justify-between">
                <ProgressBar completed={progress.completed} total={progress.total} />
                {progress.completed > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsSummaryOpen(true)}
                    className="text-violet-400 hover:text-violet-300 hover:bg-violet-500/10"
                  >
                    <Sparkles className="w-4 h-4 mr-1" />
                    Summary
                  </Button>
                )}
              </div>
            </div>
          )}
        </header>
        
        {/* Timeline View */}
        {viewMode === 'timeline' && (
          <Card className="bg-slate-800/50 border-slate-700 overflow-hidden">
            <CardContent className="p-4 max-h-[600px] overflow-y-auto">
              <TimelineView 
                selectedDate={selectedDate}
                onEditTask={handleEditTask}
              />
            </CardContent>
          </Card>
        )}
        
        {/* Eisenhower Matrix View */}
        {viewMode === 'matrix' && (
          <Card className="bg-slate-800/50 border-slate-700 overflow-hidden">
            <CardContent className="p-4">
              <EisenhowerMatrix 
                selectedDate={selectedDate}
                onEditTask={handleEditTask}
              />
            </CardContent>
          </Card>
        )}
        
        {/* Schedule View */}
        {viewMode === 'schedule' && (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6 bg-slate-800/50 border border-slate-700/50 rounded-xl p-1">
              <TabsTrigger 
                value="schedule" 
                className="flex items-center gap-2 data-[state=active]:bg-violet-500/20 data-[state=active]:text-violet-400 rounded-lg"
              >
                <CalendarIcon className="h-4 w-4" />
                Schedule
                {tasks.length > 0 && (
                  <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px] bg-slate-700">
                    {tasks.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger 
                value="daily" 
                className="flex items-center gap-2 data-[state=active]:bg-violet-500/20 data-[state=active]:text-violet-400 rounded-lg"
              >
                <Repeat className="h-4 w-4" />
                Daily Tasks
                {dailyTasks.length > 0 && (
                  <Badge variant="secondary" className="ml-1 h-5 px-1.5 text-[10px] bg-slate-700">
                    {dailyTasks.length}
                  </Badge>
                )}
              </TabsTrigger>
            </TabsList>
            
            {/* Schedule Tab */}
            <TabsContent value="schedule" className="space-y-6">
              {/* Add Task Button */}
              <Button
                onClick={() => {
                  setEditingTask(null)
                  setIsTaskFormOpen(true)
                }}
                className="w-full h-12 text-base bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600 text-white shadow-lg shadow-violet-500/25 rounded-xl"
              >
                <Plus className="h-5 w-5 mr-2" />
                Add Task for {formatDate(selectedDate)}
              </Button>
              
              {/* Quick Tasks Section */}
              {quickTasks.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm font-medium text-slate-400">
                    <Zap className="w-4 h-4 text-violet-400" />
                    Quick Tasks
                  </div>
                  <DndContext
                    sensors={sensors}
                    collisionDetection={closestCenter}
                    onDragEnd={handleDragEnd}
                  >
                    <SortableContext items={quickTasks.map(t => t.id)} strategy={verticalListSortingStrategy}>
                      <div className="grid gap-3">
                        {quickTasks.map((task) => (
                          <SortableTaskCard
                            key={task.id}
                            task={task}
                            onEdit={handleEditTask}
                          />
                        ))}
                      </div>
                    </SortableContext>
                  </DndContext>
                </div>
              )}
              
              {/* Tasks Timeline */}
              {regularTasks.length === 0 && quickTasks.length === 0 ? (
                <Card className="border-dashed border-slate-700 bg-slate-800/30">
                  <CardContent className="py-16 text-center">
                    <div className="text-slate-500">
                      <CalendarIcon className="h-16 w-16 mx-auto mb-4 opacity-30" />
                      <p className="text-lg font-medium mb-2 text-slate-400">No tasks scheduled</p>
                      <p className="text-sm text-slate-500">Add a task or set up daily tasks to get started</p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext items={taskIds} strategy={verticalListSortingStrategy}>
                    <div className="space-y-6">
                      {['Morning', 'Afternoon', 'Evening'].map((period) => {
                        const periodTasks = groupedTasks[period] || []
                        if (periodTasks.length === 0) return null
                        
                        const periodColors = {
                          Morning: 'from-amber-500 to-orange-500',
                          Afternoon: 'from-sky-500 to-cyan-500',
                          Evening: 'from-violet-500 to-purple-500'
                        }
                        
                        return (
                          <div key={period} className="space-y-3">
                            <div className="flex items-center gap-3">
                              <span className={cn(
                                "w-2 h-2 rounded-full bg-gradient-to-r",
                                periodColors[period]
                              )} />
                              <h3 className="text-sm font-semibold text-slate-300">{period}</h3>
                              <div className="flex-1 h-px bg-slate-700/50" />
                            </div>
                            <div className="grid gap-3">
                              {periodTasks.map((task) => (
                                <SortableTaskCard
                                  key={task.id}
                                  task={task}
                                  onEdit={handleEditTask}
                                />
                              ))}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </SortableContext>
                </DndContext>
              )}
            </TabsContent>
            
            {/* Daily Tasks Tab */}
            <TabsContent value="daily" className="space-y-6">
              {/* Add Daily Task Button */}
              <Button
                onClick={() => {
                  setEditingDailyTask(null)
                  setIsDailyFormOpen(true)
                }}
                className="w-full h-12 text-base bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white shadow-lg shadow-emerald-500/25 rounded-xl"
              >
                <Plus className="h-5 w-5 mr-2" />
                Add Daily Task
              </Button>
              
              {/* Daily Tasks List */}
              {dailyTasks.length === 0 ? (
                <Card className="border-dashed border-slate-700 bg-slate-800/30">
                  <CardContent className="py-16 text-center">
                    <div className="text-slate-500">
                      <Repeat className="h-16 w-16 mx-auto mb-4 opacity-30" />
                      <p className="text-lg font-medium mb-2 text-slate-400">No daily tasks</p>
                      <p className="text-sm text-slate-500">Add tasks you do every day and they&apos;ll automatically appear on your schedule</p>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-3">
                  {dailyTasks
                    .sort((a, b) => a.startTime.localeCompare(b.startTime))
                    .map((task) => (
                      <SortableTaskCard
                        key={task.id}
                        task={task}
                        onEdit={handleEditDailyTask}
                        isDailyTemplate={true}
                      />
                    ))}
                </div>
              )}
              
              {/* Info Card */}
              {dailyTasks.length > 0 && (
                <Card className="bg-emerald-500/10 border-emerald-500/20">
                  <CardContent className="py-4 px-4">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="h-5 w-5 text-emerald-400 mt-0.5 shrink-0" />
                      <div className="text-sm text-slate-300">
                        <p className="font-medium text-emerald-400 mb-1">Daily Tasks</p>
                        <p className="text-slate-400">These tasks will automatically appear on every day&apos;s schedule. You can mark them complete each day independently.</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        )}
        
        {/* Footer */}
        <footer className="mt-10 text-center text-xs text-slate-600">
          <p>Data is saved locally in your browser</p>
          <p className="mt-1 text-slate-700">Undo: Ctrl+Z | Redo: Ctrl+Y</p>
        </footer>
      </div>
      
      {/* Forms */}
      <TaskForm
        open={isTaskFormOpen}
        onOpenChange={(open) => {
          setIsTaskFormOpen(open)
          if (!open) setEditingTask(null)
        }}
        editTask={editingTask}
        defaultDate={selectedDate}
      />
      
      <DailyTaskForm
        open={isDailyFormOpen}
        onOpenChange={(open) => {
          setIsDailyFormOpen(open)
          if (!open) setEditingDailyTask(null)
        }}
        editTask={editingDailyTask}
      />
      
      <SettingsDialog
        open={isSettingsOpen}
        onOpenChange={setIsSettingsOpen}
      />
      
      <DailySummary
        open={isSummaryOpen}
        onOpenChange={setIsSummaryOpen}
      />
      
      {/* Stats Dialog */}
      {isStatsOpen && (
        <Card className="fixed inset-4 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-[500px] md:max-h-[80vh] overflow-y-auto bg-slate-900 border-slate-700 z-50 shadow-2xl">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-violet-400" />
                Statistics
              </h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsStatsOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                Close
              </Button>
            </div>
            <CompletionStats />
          </CardContent>
        </Card>
      )}
    </div>
  )
}
