import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface SettingsStore {
  telegramWebhookUrl: string
  notificationsEnabled: boolean
  notifyMinutesBefore: number
  theme: 'light' | 'dark' | 'system'
  soundEnabled: boolean
  soundVolume: number
  
  // Actions
  setTelegramWebhookUrl: (url: string) => void
  setNotificationsEnabled: (enabled: boolean) => void
  setNotifyMinutesBefore: (minutes: number) => void
  setTheme: (theme: 'light' | 'dark' | 'system') => void
  setSoundEnabled: (enabled: boolean) => void
  setSoundVolume: (volume: number) => void
}

export const useSettingsStore = create<SettingsStore>()(
  persist(
    (set) => ({
      telegramWebhookUrl: '',
      notificationsEnabled: false,
      notifyMinutesBefore: 5,
      theme: 'dark',
      soundEnabled: true,
      soundVolume: 0.5,
      
      setTelegramWebhookUrl: (url) => set({ telegramWebhookUrl: url }),
      setNotificationsEnabled: (enabled) => set({ notificationsEnabled: enabled }),
      setNotifyMinutesBefore: (minutes) => set({ notifyMinutesBefore: minutes }),
      setTheme: (theme) => set({ theme }),
      setSoundEnabled: (enabled) => set({ soundEnabled: enabled }),
      setSoundVolume: (volume) => set({ soundVolume: volume }),
    }),
    {
      name: 'day-organizer-settings',
    }
  )
)

// Telegram notification function
export async function sendTelegramNotification(
  webhookUrl: string, 
  taskTitle: string, 
  startTime: string,
  endTime: string
): Promise<boolean> {
  if (!webhookUrl) return false
  
  try {
    const message = `⏰ *Task Reminder!*\n\n📌 **${taskTitle}**\n🕐 Time: ${startTime} - ${endTime}\n\nGet ready! Your task starts in 5 minutes.`
    
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: message,
        parse_mode: 'Markdown',
      }),
    })
    
    return response.ok
  } catch (error) {
    console.error('Failed to send Telegram notification:', error)
    return false
  }
}
