'use client'

import { useState, useEffect } from 'react'
import { Task, useTaskStore, getTodayDate, UrgencyLevel, URGENCY_LABELS } from '@/store/taskStore'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Calendar } from '@/components/ui/calendar'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { cn } from '@/lib/utils'
import { format, addYears, isSameDay } from 'date-fns'
import { CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react'

interface TaskFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  editTask?: Task | null
  defaultDate?: string
}

const HOURS = Array.from({ length: 24 }, (_, i) => i)
const MINUTES = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55]

const URGENCY_COLORS_SELECT: Record<UrgencyLevel, string> = {
  low: 'bg-emerald-500',
  medium: 'bg-sky-500',
  high: 'bg-amber-500',
  urgent: 'bg-rose-500',
}

export function TaskForm({ open, onOpenChange, editTask, defaultDate }: TaskFormProps) {
  const { addTask, updateTask } = useTaskStore()
  
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [startHour, setStartHour] = useState('9')
  const [startMinute, setStartMinute] = useState('00')
  const [endHour, setEndHour] = useState('10')
  const [endMinute, setEndMinute] = useState('00')
  const [urgency, setUrgency] = useState<UrgencyLevel>('medium')
  const [isQuick, setIsQuick] = useState(false)
  const [calendarMonth, setCalendarMonth] = useState<Date>(new Date())
  
  // Update form when editTask changes
  useEffect(() => {
    if (open) {
      if (editTask) {
        setTitle(editTask.title)
        setDescription(editTask.description || '')
        setSelectedDate(new Date(editTask.date + 'T00:00:00'))
        setCalendarMonth(new Date(editTask.date + 'T00:00:00'))
        setStartHour(editTask.startTime.split(':')[0])
        setStartMinute(editTask.startTime.split(':')[1])
        setEndHour(editTask.endTime.split(':')[0])
        setEndMinute(editTask.endTime.split(':')[1])
        setUrgency(editTask.urgency || 'medium')
        setIsQuick(editTask.isQuick || false)
      } else {
        // Reset to defaults for new task
        setTitle('')
        setDescription('')
        const date = defaultDate ? new Date(defaultDate + 'T00:00:00') : new Date()
        setSelectedDate(date)
        setCalendarMonth(date)
        setStartHour('9')
        setStartMinute('00')
        setEndHour('10')
        setEndMinute('00')
        setUrgency('medium')
        setIsQuick(false)
      }
    }
  }, [open, editTask, defaultDate])
  
  const handleSubmit = () => {
    if (!title.trim()) return
    
    const startTime = `${startHour.padStart(2, '0')}:${startMinute.padStart(2, '0')}`
    const endTime = `${endHour.padStart(2, '0')}:${endMinute.padStart(2, '0')}`
    const dateStr = format(selectedDate, 'yyyy-MM-dd')
    
    if (editTask) {
      updateTask(editTask.id, {
        title: title.trim(),
        description: description.trim() || undefined,
        date: dateStr,
        startTime,
        endTime,
        urgency,
        isQuick,
      })
    } else {
      addTask({
        title: title.trim(),
        description: description.trim() || undefined,
        startTime,
        endTime,
        date: dateStr,
        isDaily: false,
        urgency,
        isQuick,
      })
    }
    
    onOpenChange(false)
  }
  
  const formatHour = (h: string) => {
    const hour = parseInt(h)
    const ampm = hour >= 12 ? 'PM' : 'AM'
    const h12 = hour % 12 || 12
    return `${h12} ${ampm}`
  }

  const handlePrevMonth = () => {
    setCalendarMonth(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1))
  }

  const handleNextMonth = () => {
    setCalendarMonth(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1))
  }

  // Generate quick date buttons
  const quickDates = [
    { label: 'Today', date: new Date() },
    { label: 'Tomorrow', date: new Date(Date.now() + 86400000) },
    { label: '+1 Week', date: new Date(Date.now() + 7 * 86400000) },
    { label: '+3 Months', date: new Date(Date.now() + 90 * 86400000) },
    { label: '+6 Months', date: new Date(Date.now() + 180 * 86400000) },
  ]
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[420px] bg-slate-900 border-slate-700 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">{editTask ? 'Edit Task' : 'Add New Task'}</DialogTitle>
          {editTask && (
            <p className="text-sm text-slate-400">Editing: {editTask.title}</p>
          )}
        </DialogHeader>
        
        <div className="space-y-5 py-2">
          <div className="space-y-2">
            <Label htmlFor="title" className="text-sm font-medium">Title</Label>
            <Input
              id="title"
              placeholder="What do you need to do?"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              autoFocus
              className="bg-slate-800 border-slate-600 focus:border-violet-500"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description" className="text-sm font-medium">Description <span className="text-slate-500">(optional)</span></Label>
            <Input
              id="description"
              placeholder="Add details..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="bg-slate-800 border-slate-600 focus:border-violet-500"
            />
          </div>

          {/* Date Picker */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Date</Label>
            
            {/* Quick date buttons */}
            <div className="flex gap-2 flex-wrap">
              {quickDates.map((qd) => (
                <Button
                  key={qd.label}
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedDate(qd.date)
                    setCalendarMonth(qd.date)
                  }}
                  className={cn(
                    "text-xs border-slate-600",
                    isSameDay(selectedDate, qd.date) 
                      ? "bg-violet-500/20 border-violet-500 text-violet-300" 
                      : "hover:bg-slate-800"
                  )}
                >
                  {qd.label}
                </Button>
              ))}
            </div>

            {/* Calendar popover */}
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal bg-slate-800 border-slate-600",
                    !selectedDate && "text-slate-400"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {selectedDate ? format(selectedDate, 'EEEE, MMMM d, yyyy') : 'Pick a date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 bg-slate-800 border-slate-700" align="start">
                <div className="p-3 border-b border-slate-700">
                  <div className="flex items-center justify-between">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handlePrevMonth}
                      className="h-7 w-7 text-slate-400 hover:text-white"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm font-medium">
                      {format(calendarMonth, 'MMMM yyyy')}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleNextMonth}
                      className="h-7 w-7 text-slate-400 hover:text-white"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => {
                    if (date) {
                      setSelectedDate(date)
                    }
                  }}
                  month={calendarMonth}
                  onMonthChange={setCalendarMonth}
                  disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                  className="bg-slate-800 text-white"
                  classNames={{
                    day_selected: "bg-violet-500 text-white hover:bg-violet-600",
                    day_today: "bg-slate-700 text-white",
                    day_disabled: "text-slate-600 opacity-50",
                    day: "text-slate-300 hover:bg-slate-700 rounded-md",
                  }}
                  fromDate={new Date()}
                  toDate={addYears(new Date(), 10)} // Allow up to 10 years ahead
                />
              </PopoverContent>
            </Popover>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium">Start Time</Label>
              <div className="flex gap-2">
                <Select value={startHour} onValueChange={setStartHour}>
                  <SelectTrigger className="flex-1 bg-slate-800 border-slate-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {HOURS.map((h) => (
                      <SelectItem key={h} value={h.toString()} className="hover:bg-slate-700">
                        {formatHour(h.toString())}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={startMinute} onValueChange={setStartMinute}>
                  <SelectTrigger className="w-[70px] bg-slate-800 border-slate-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {MINUTES.map((m) => (
                      <SelectItem key={m} value={m.toString().padStart(2, '0')} className="hover:bg-slate-700">
                        :{m.toString().padStart(2, '0')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-medium">End Time</Label>
              <div className="flex gap-2">
                <Select value={endHour} onValueChange={setEndHour}>
                  <SelectTrigger className="flex-1 bg-slate-800 border-slate-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {HOURS.map((h) => (
                      <SelectItem key={h} value={h.toString()} className="hover:bg-slate-700">
                        {formatHour(h.toString())}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={endMinute} onValueChange={setEndMinute}>
                  <SelectTrigger className="w-[70px] bg-slate-800 border-slate-600">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {MINUTES.map((m) => (
                      <SelectItem key={m} value={m.toString().padStart(2, '0')} className="hover:bg-slate-700">
                        :{m.toString().padStart(2, '0')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          {/* Urgency Selector */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Urgency Level</Label>
            <Select value={urgency} onValueChange={(v) => setUrgency(v as UrgencyLevel)}>
              <SelectTrigger className="bg-slate-800 border-slate-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                {(Object.keys(URGENCY_LABELS) as UrgencyLevel[]).map((level) => (
                  <SelectItem key={level} value={level} className="hover:bg-slate-700">
                    <div className="flex items-center gap-2">
                      <span className={cn("w-2 h-2 rounded-full", URGENCY_COLORS_SELECT[level])} />
                      {URGENCY_LABELS[level]}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[10px] text-slate-500">How time-sensitive is this task?</p>
          </div>
          
          <div className="flex items-center justify-between p-3 rounded-lg bg-slate-800 border border-slate-700">
            <div className="space-y-0.5">
              <Label className="text-sm font-medium">Quick Task</Label>
              <p className="text-xs text-slate-500">Mark as a quick, easy-to-complete task</p>
            </div>
            <Switch
              checked={isQuick}
              onCheckedChange={setIsQuick}
            />
          </div>
        </div>
        
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="flex-1 border-slate-600 hover:bg-slate-800">
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!title.trim()} className="flex-1 bg-violet-500 hover:bg-violet-600">
            {editTask ? 'Save Changes' : 'Add Task'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
