import type { Handler } from '@netlify/functions'

const JSONBLOB_API = 'https://jsonblob.com/api/jsonBlob'

export const handler: Handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
    'Content-Type': 'application/json'
  }

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' }
  }

  const path = event.path.split('/')
  const action = path[path.length - 1]
  const blobId = event.queryStringParameters?.id

  try {
    // Create new sync
    if (event.httpMethod === 'POST') {
      const response = await fetch(JSONBLOB_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: event.body || '{}'
      })
      
      const location = response.headers.get('Location') || ''
      const newBlobId = location.split('/').pop() || ''
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ 
          success: true, 
          blobId: newBlobId,
          data: await response.json().catch(() => ({}))
        })
      }
    }

    // Get sync data
    if (event.httpMethod === 'GET' && blobId) {
      const response = await fetch(`${JSONBLOB_API}/${blobId}`)
      
      if (!response.ok) {
        return {
          statusCode: response.status,
          headers,
          body: JSON.stringify({ success: false, error: 'Not found' })
        }
      }
      
      const data = await response.json()
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, data })
      }
    }

    // Update sync data
    if (event.httpMethod === 'PUT' && blobId) {
      const response = await fetch(`${JSONBLOB_API}/${blobId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: event.body || '{}'
      })
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ 
          success: response.ok,
          data: await response.json().catch(() => ({}))
        })
      }
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ success: false, error: 'Invalid request' })
    }
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Server error' 
      })
    }
  }
}
