'use client'

import { useEffect, useRef, useCallback } from 'react'
import { useTaskStore, getTodayDate } from '@/store/taskStore'
import { useSettingsStore, sendTelegramNotification } from '@/store/settingsStore'
import { soundManager } from '@/lib/sounds'

export function useNotifications() {
  const tasks = useTaskStore(state => state.tasks)
  const markNotified = useTaskStore(state => state.markNotified)
  const { telegramWebhookUrl, notificationsEnabled, notifyMinutesBefore, soundEnabled } = useSettingsStore()
  const notifiedRef = useRef<Set<string>>(new Set())
  const lastCheckRef = useRef<number>(0)
  
  const checkAndNotify = useCallback(async () => {
    // Debounce - only check once per minute max
    const now = Date.now()
    if (now - lastCheckRef.current < 60000) return
    lastCheckRef.current = now
    
    if (!notificationsEnabled || !telegramWebhookUrl) return
    
    const today = getTodayDate()
    const currentDate = new Date()
    const currentMinutes = currentDate.getHours() * 60 + currentDate.getMinutes()
    
    // Get today's tasks that haven't been notified and aren't completed
    const todayTasks = tasks.filter(task => {
      if (task.isDaily) {
        // For daily tasks, check daily instances
        const instanceId = `daily-${task.id}-${today}`
        return !tasks.find(t => t.id === instanceId && t.completed)
      }
      return task.date === today && !task.completed
    })
    
    for (const task of todayTasks) {
      // Skip if already notified
      if (notifiedRef.current.has(task.id)) continue
      if (task.notifySent) continue
      
      // Parse start time
      const [hours, mins] = task.startTime.split(':').map(Number)
      const taskMinutes = hours * 60 + mins
      
      // Calculate minutes until task
      const minutesUntil = taskMinutes - currentMinutes
      
      // Check if we should notify (within the notification window and not past)
      if (minutesUntil > 0 && minutesUntil <= notifyMinutesBefore) {
        console.log(`Notifying for task: ${task.title}, minutes until: ${minutesUntil}`)
        
        // Send Telegram notification
        const success = await sendTelegramNotification(
          telegramWebhookUrl,
          task.title,
          task.startTime,
          task.endTime
        )
        
        if (success) {
          notifiedRef.current.add(task.id)
          markNotified(task.id)
          
          // Play sound if enabled
          if (soundEnabled) {
            soundManager.play('notification')
          }
        }
      }
    }
  }, [tasks, notificationsEnabled, telegramWebhookUrl, notifyMinutesBefore, markNotified, soundEnabled])
  
  useEffect(() => {
    // Check immediately on mount
    checkAndNotify()
    
    // Check every minute
    const interval = setInterval(checkAndNotify, 60000)
    
    return () => clearInterval(interval)
  }, [checkAndNotify])
  
  return null
}
