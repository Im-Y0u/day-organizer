'use client'

import { useState, useEffect, useCallback } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import { useTaskStore } from '@/store/taskStore'
import { useSyncStore, generateSyncId } from '@/store/syncStore'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { 
  Link2, Copy, Check, Cloud, CloudOff, 
  RefreshCw, Smartphone, Monitor, X, Loader2
} from 'lucide-react'

interface SyncDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

// Simple encoding for URL
const encodeTasks = (tasks: unknown): string => {
  try {
    return btoa(encodeURIComponent(JSON.stringify(tasks)))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '')
  } catch {
    return ''
  }
}

const decodeTasks = (encoded: string): unknown => {
  try {
    let base64 = encoded.replace(/-/g, '+').replace(/_/g, '/')
    while (base64.length % 4) base64 += '='
    return JSON.parse(decodeURIComponent(atob(base64)))
  } catch {
    return null
  }
}

export function SyncDialog({ open, onOpenChange }: SyncDialogProps) {
  const { tasks, restoreTasks } = useTaskStore()
  const { syncId, setSyncId, lastSyncTime, setLastSyncTime, clearSync } = useSyncStore()
  
  const [copied, setCopied] = useState(false)
  const [joinCode, setJoinCode] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [mode, setMode] = useState<'menu' | 'manage'>('menu')
  const [syncData, setSyncData] = useState<string>('')
  
  // Create sync URL with encoded tasks
  const syncUrl = syncData 
    ? `${typeof window !== 'undefined' ? window.location.origin : ''}/schedule?data=${syncData}` 
    : ''
  
  // Load from URL on mount
  useEffect(() => {
    if (typeof window === 'undefined') return
    
    // Check for saved sync
    const savedSyncId = localStorage.getItem('sync-id')
    if (savedSyncId) {
      setSyncId(savedSyncId)
      setMode('manage')
    }
    
    // Check URL for data
    const urlParams = new URLSearchParams(window.location.search)
    const dataParam = urlParams.get('data')
    
    if (dataParam) {
      const decoded = decodeTasks(dataParam)
      if (decoded && Array.isArray(decoded)) {
        restoreTasks(decoded as typeof tasks)
        setSuccess('Tasks loaded from link!')
        setTimeout(() => setSuccess(null), 3000)
        
        // Clear URL
        window.history.replaceState({}, '', window.location.pathname)
      }
    }
  }, [])
  
  // Create sync link
  const createSync = () => {
    const id = generateSyncId()
    setSyncId(id)
    localStorage.setItem('sync-id', id)
    
    const encoded = encodeTasks(tasks)
    setSyncData(encoded)
    setLastSyncTime(Date.now())
    setMode('manage')
    setSuccess('Sync link created!')
    setTimeout(() => setSuccess(null), 3000)
  }
  
  // Refresh sync link with current tasks
  const refreshSync = () => {
    const encoded = encodeTasks(tasks)
    setSyncData(encoded)
    setLastSyncTime(Date.now())
    setSuccess('Link updated!')
    setTimeout(() => setSuccess(null), 2000)
  }
  
  // Join from link
  const joinFromLink = () => {
    const code = joinCode.trim()
    
    if (code.includes('data=')) {
      const match = code.match(/data=([^&]+)/)
      if (match) {
        const decoded = decodeTasks(match[1])
        if (decoded && Array.isArray(decoded)) {
          restoreTasks(decoded as typeof tasks)
          setSuccess('Tasks loaded!')
          setTimeout(() => setSuccess(null), 3000)
          return
        }
      }
    }
    
    setError('Invalid link. Paste the full share link.')
    setTimeout(() => setError(null), 3000)
  }
  
  // Leave sync
  const leaveSync = () => {
    clearSync()
    localStorage.removeItem('sync-id')
    setSyncData('')
    setMode('menu')
  }
  
  // Copy
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  
  // Auto-update sync data when tasks change
  useEffect(() => {
    if (mode === 'manage' && syncId) {
      const encoded = encodeTasks(tasks)
      if (encoded) {
        setSyncData(encoded)
      }
    }
  }, [tasks, mode, syncId])
  
  if (!open) return null
  
  // Check if URL is too long for QR
  const urlTooLong = syncUrl.length > 2000
  
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => onOpenChange(false)}>
      <Card 
        className="bg-slate-900 border-slate-700 w-full max-w-md shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <Cloud className="w-5 h-5 text-violet-400" />
            Share Tasks
          </CardTitle>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onOpenChange(false)}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {success && (
            <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3 text-sm text-emerald-400">
              {success}
            </div>
          )}
          
          {error && (
            <div className="bg-rose-500/10 border border-rose-500/20 rounded-lg p-3 text-sm text-rose-400">
              {error}
            </div>
          )}
          
          {/* Menu */}
          {mode === 'menu' && !syncId && (
            <div className="space-y-3">
              <p className="text-sm text-slate-400 text-center mb-4">
                Share your tasks via link or QR code
              </p>
              
              <Button
                onClick={createSync}
                className="w-full h-16 flex-col gap-1 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500"
              >
                <Monitor className="w-5 h-5" />
                <span className="text-sm">Create Share Link</span>
                <span className="text-xs opacity-75">Generate QR code</span>
              </Button>
              
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-slate-700" />
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-slate-900 px-2 text-slate-500">or</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <Input
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value)}
                  placeholder="Paste share link here..."
                  className="text-sm bg-slate-800 border-slate-600 h-12"
                />
                <Button 
                  onClick={joinFromLink}
                  variant="outline"
                  className="w-full border-slate-600"
                  disabled={!joinCode.includes('data=')}
                >
                  Load Tasks
                </Button>
              </div>
            </div>
          )}
          
          {/* Manage */}
          {mode === 'manage' && syncId && (
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-xs text-slate-500 mb-2">Sync Code</p>
                <div className="flex items-center justify-center gap-2">
                  <code className="text-2xl font-mono font-bold tracking-widest text-violet-400 bg-violet-500/10 px-4 py-2 rounded-lg">
                    {syncId}
                  </code>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => copyToClipboard(syncId || '')}
                    className="h-10 w-10"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              
              {/* QR Code */}
              {syncUrl && !urlTooLong && (
                <div className="flex justify-center">
                  <div className="bg-white p-4 rounded-xl shadow-lg">
                    <QRCodeSVG 
                      value={syncUrl} 
                      size={160}
                      level="L"
                      includeMargin={false}
                    />
                  </div>
                </div>
              )}
              
              {urlTooLong && (
                <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 text-sm text-amber-400 text-center">
                  Too many tasks for QR. Use the link instead.
                </div>
              )}
              
              {/* Link */}
              {syncUrl && (
                <div className="space-y-2">
                  <p className="text-xs text-slate-500 text-center">
                    {urlTooLong ? 'Copy this link' : 'Scan QR or copy link'}
                  </p>
                  <div className="flex gap-2">
                    <Input
                      value={syncUrl}
                      readOnly
                      className="text-xs bg-slate-800 border-slate-700 h-9"
                    />
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => copyToClipboard(syncUrl)}
                      className="shrink-0 h-9 w-9"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Link2 className="w-3.5 h-3.5" />}
                    </Button>
                  </div>
                </div>
              )}
              
              {lastSyncTime && (
                <p className="text-xs text-slate-500 text-center">
                  Updated: {new Date(lastSyncTime).toLocaleTimeString()}
                </p>
              )}
              
              <Button
                onClick={refreshSync}
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Update Link
              </Button>
              
              <Button
                variant="ghost"
                onClick={leaveSync}
                className="w-full text-slate-400 hover:text-rose-400 hover:bg-rose-500/10"
              >
                <CloudOff className="w-4 h-4 mr-2" />
                Clear Sync
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
