'use client'

import { useState, useEffect } from 'react'
import { useSettingsStore, testTelegramConnection } from '@/store/settingsStore'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Bell, Send, CheckCircle2, XCircle, Loader2, Volume2, VolumeX, Play, Info } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { soundManager } from '@/lib/sounds'

interface SettingsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const { 
    telegramWebhookUrl, 
    setTelegramWebhookUrl,
    notificationsEnabled,
    setNotificationsEnabled,
    notifyMinutesBefore,
    setNotifyMinutesBefore,
    soundEnabled,
    setSoundEnabled
  } = useSettingsStore()
  
  const [testStatus, setTestStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [testMessage, setTestMessage] = useState('')
  
  const handleTestNotification = async () => {
    if (!telegramWebhookUrl) return
    
    setTestStatus('loading')
    setTestMessage('')
    
    const result = await testTelegramConnection(telegramWebhookUrl)
    
    setTestStatus(result.success ? 'success' : 'error')
    setTestMessage(result.message)
    
    setTimeout(() => {
      setTestStatus('idle')
      setTestMessage('')
    }, 5000)
  }
  
  const handleTestSound = () => {
    soundManager.play('notification')
  }
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-slate-900 border-slate-700 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Settings
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 py-4">
          {/* Sound Settings */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
              Sound Alerts
            </h3>
            
            <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50 border border-slate-700">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Enable Sounds</Label>
                <p className="text-xs text-slate-400">
                  Play sound when task notification triggers
                </p>
              </div>
              <Switch
                checked={soundEnabled}
                onCheckedChange={(enabled) => {
                  setSoundEnabled(enabled)
                  soundManager.setEnabled(enabled)
                }}
              />
            </div>
            
            {soundEnabled && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleTestSound}
                className="w-full border-slate-600 hover:bg-slate-800"
              >
                <Play className="w-4 h-4 mr-2" />
                Test Sound
              </Button>
            )}
          </div>
          
          {/* Divider */}
          <div className="border-t border-slate-700" />
          
          {/* Telegram Notifications */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
              <Send className="w-4 h-4 text-sky-400" />
              Telegram Notifications
            </h3>
            
            {/* How to setup */}
            <div className="bg-sky-500/10 border border-sky-500/20 rounded-lg p-3 text-xs text-sky-300">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium mb-2">How to get your webhook URL:</p>
                  <ol className="list-decimal list-inside space-y-1 text-sky-200/80">
                    <li>Open Telegram and search for @BotFather</li>
                    <li>Send /newbot and follow instructions to create a bot</li>
                    <li>Copy the bot token (e.g., 123456:ABC...)</li>
                    <li>Search for @userinfobot and send any message</li>
                    <li>Copy your chat ID (a number)</li>
                    <li>Build URL: https://api.telegram.org/botTOKEN/sendMessage?chat_id=ID</li>
                  </ol>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-sm font-medium">Telegram Webhook URL</Label>
              <Input
                placeholder="https://api.telegram.org/bot123456:ABC.../sendMessage?chat_id=123456789"
                value={telegramWebhookUrl}
                onChange={(e) => setTelegramWebhookUrl(e.target.value)}
                className="bg-slate-800 border-slate-600 font-mono text-xs"
              />
              <p className="text-xs text-slate-500">
                Replace TOKEN with your bot token and chat_id with your chat ID
              </p>
            </div>
            
            {/* Test Button */}
            {telegramWebhookUrl && (
              <div className="space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleTestNotification}
                  disabled={testStatus === 'loading' || !telegramWebhookUrl.includes('api.telegram.org')}
                  className="flex items-center gap-2 border-slate-600 hover:bg-slate-800"
                >
                  {testStatus === 'loading' ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  Test Connection
                </Button>
                
                {testStatus === 'success' && (
                  <div className="flex items-center gap-2 text-sm text-emerald-400">
                    <CheckCircle2 className="w-4 h-4" />
                    {testMessage || 'Check your Telegram!'}
                  </div>
                )}
                {testStatus === 'error' && (
                  <div className="flex items-center gap-2 text-sm text-rose-400">
                    <XCircle className="w-4 h-4" />
                    {testMessage || 'Failed. Check URL format.'}
                  </div>
                )}
              </div>
            )}
            
            {/* Enable Notifications */}
            <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50 border border-slate-700">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Enable Notifications</Label>
                <p className="text-xs text-slate-400">
                  Get Telegram alerts before tasks start
                </p>
              </div>
              <Switch
                checked={notificationsEnabled}
                onCheckedChange={setNotificationsEnabled}
                disabled={!telegramWebhookUrl}
              />
            </div>
            
            {/* Notify Before */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Notify Before</Label>
              <Select 
                value={notifyMinutesBefore.toString()} 
                onValueChange={(v) => setNotifyMinutesBefore(parseInt(v))}
                disabled={!notificationsEnabled}
              >
                <SelectTrigger className="bg-slate-800 border-slate-600">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 minute before</SelectItem>
                  <SelectItem value="5">5 minutes before</SelectItem>
                  <SelectItem value="10">10 minutes before</SelectItem>
                  <SelectItem value="15">15 minutes before</SelectItem>
                  <SelectItem value="30">30 minutes before</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Note about when notifications work */}
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 text-xs text-amber-300">
            <p>💡 <strong>Note:</strong> Notifications work when this app is open in a browser tab. For 24/7 notifications without keeping the app open, you'll need to deploy with a server.</p>
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            onClick={() => onOpenChange(false)} 
            className="w-full bg-violet-500 hover:bg-violet-600"
          >
            Done
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
