'use client'

import { useEffect, useRef } from 'react'
import { useSettingsStore } from '@/store/settingsStore'
import { useStatsStore } from '@/store/statsStore'
import { useHistoryStore } from '@/store/historyStore'
import { useNotifications } from '@/hooks/useNotifications'
import { soundManager } from '@/lib/sounds'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Settings, BarChart3, Undo2, Redo2, Flame, LayoutList, Clock, Grid3X3, Cloud } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useSyncStore } from '@/store/syncStore'

interface AppLayoutProps {
  children: React.ReactNode
  onOpenSettings?: () => void
  onOpenStats?: () => void
  onOpenSync?: () => void
}

export function AppLayout({ children, onOpenSettings, onOpenStats, onOpenSync }: AppLayoutProps) {
  const pathname = usePathname()
  const { soundEnabled } = useSettingsStore()
  const { currentStreak } = useStatsStore()
  const { canUndo, canRedo, undo, redo } = useHistoryStore()
  const { syncId } = useSyncStore()
  const mountedRef = useRef(false)

  useNotifications()

  useEffect(() => {
    mountedRef.current = true
    soundManager.setEnabled(soundEnabled)
  }, [soundEnabled])

  const navItems = [
    { href: '/schedule', icon: LayoutList, label: 'Schedule' },
    { href: '/timeline', icon: Clock, label: 'Timeline' },
    { href: '/matrix', icon: Grid3X3, label: 'Matrix' },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Header */}
        <header className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <Link href="/schedule">
              <h1 className="text-2xl font-bold tracking-tight bg-gradient-to-r from-violet-400 via-fuchsia-400 to-pink-400 bg-clip-text text-transparent cursor-pointer">
                Day Organizer
              </h1>
            </Link>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => undo()}
                disabled={!canUndo()}
                className="h-8 w-8 text-slate-500 hover:text-white hover:bg-white/5 disabled:opacity-30"
                title="Undo"
              >
                <Undo2 className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => redo()}
                disabled={!canRedo()}
                className="h-8 w-8 text-slate-500 hover:text-white hover:bg-white/5 disabled:opacity-30"
                title="Redo"
              >
                <Redo2 className="h-4 w-4" />
              </Button>

              {currentStreak > 0 && (
                <Badge className="bg-orange-500/15 text-orange-400 border-orange-500/20 gap-1 ml-2">
                  <Flame className="w-3.5 h-3.5" />
                  {currentStreak}
                </Badge>
              )}

              {/* Sync button */}
              {onOpenSync && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onOpenSync}
                  className={cn(
                    "h-8 w-8",
                    syncId 
                      ? "text-violet-400 hover:text-violet-300 hover:bg-violet-500/10" 
                      : "text-slate-500 hover:text-white hover:bg-white/5"
                  )}
                  title="Sync across devices"
                >
                  <Cloud className="h-4 w-4" />
                </Button>
              )}

              {onOpenStats && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onOpenStats}
                  className="h-8 w-8 text-slate-500 hover:text-white hover:bg-white/5"
                >
                  <BarChart3 className="h-4 w-4" />
                </Button>
              )}

              {onOpenSettings && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onOpenSettings}
                  className="h-8 w-8 text-slate-500 hover:text-white hover:bg-white/5"
                >
                  <Settings className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center gap-2 bg-slate-800/30 p-1 rounded-xl">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = pathname === item.href
              return (
                <Link key={item.href} href={item.href} className="flex-1">
                  <Button
                    variant="ghost"
                    className={cn(
                      "w-full gap-2 h-9 text-sm font-medium transition-all",
                      isActive
                        ? "bg-white/10 text-white shadow-sm"
                        : "text-slate-400 hover:text-white hover:bg-white/5"
                    )}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </Button>
                </Link>
              )
            })}
          </div>
        </header>

        {children}

        <footer className="text-center text-xs text-slate-600 mt-8 py-4">
          <p>Data saved locally in your browser</p>
          <p className="mt-1 text-slate-700">Undo: Ctrl+Z • Redo: Ctrl+Y</p>
        </footer>
      </div>
    </div>
  )
}
