import { create } from 'zustand'

export interface SyncState {
  syncId: string | null
  syncEnabled: boolean
  lastSyncTime: number | null
  isSyncing: boolean
  
  // Actions
  setSyncId: (id: string | null) => void
  setSyncEnabled: (enabled: boolean) => void
  setLastSyncTime: (time: number) => void
  setIsSyncing: (syncing: boolean) => void
  clearSync: () => void
}

// Generate a random sync ID
export const generateSyncId = (): string => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let result = ''
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

export const useSyncStore = create<SyncState>((set) => ({
  syncId: null,
  syncEnabled: false,
  lastSyncTime: null,
  isSyncing: false,
  
  setSyncId: (id) => set({ syncId: id, syncEnabled: !!id }),
  setSyncEnabled: (enabled) => set({ syncEnabled: enabled }),
  setLastSyncTime: (time) => set({ lastSyncTime: time }),
  setIsSyncing: (syncing) => set({ isSyncing: syncing }),
  clearSync: () => set({ syncId: null, syncEnabled: false, lastSyncTime: null }),
}))
