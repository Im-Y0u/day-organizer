import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface SettingsStore {
  telegramWebhookUrl: string
  notificationsEnabled: boolean
  notifyMinutesBefore: number
  soundEnabled: boolean
  soundVolume: number
  
  // Actions
  setTelegramWebhookUrl: (url: string) => void
  setNotificationsEnabled: (enabled: boolean) => void
  setNotifyMinutesBefore: (minutes: number) => void
  setSoundEnabled: (enabled: boolean) => void
  setSoundVolume: (volume: number) => void
}

export const useSettingsStore = create<SettingsStore>()(
  persist(
    (set) => ({
      telegramWebhookUrl: '',
      notificationsEnabled: false,
      notifyMinutesBefore: 5,
      soundEnabled: true,
      soundVolume: 0.5,
      
      setTelegramWebhookUrl: (url) => set({ telegramWebhookUrl: url }),
      setNotificationsEnabled: (enabled) => set({ notificationsEnabled: enabled }),
      setNotifyMinutesBefore: (minutes) => set({ notifyMinutesBefore: minutes }),
      setSoundEnabled: (enabled) => set({ soundEnabled: enabled }),
      setSoundVolume: (volume) => set({ soundVolume: volume }),
    }),
    {
      name: 'day-organizer-settings',
    }
  )
)

// Telegram notification function
export async function sendTelegramNotification(
  webhookUrl: string, 
  taskTitle: string, 
  startTime: string,
  endTime: string
): Promise<boolean> {
  if (!webhookUrl) {
    console.error('No webhook URL provided')
    return false
  }
  
  try {
    // Format message
    const message = `⏰ *Task Reminder!*\n\n📌 **${taskTitle}**\n🕐 Time: ${startTime} - ${endTime}\n\nYour task is starting soon!`
    
    console.log('Sending Telegram notification to:', webhookUrl.substring(0, 50) + '...')
    
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: message,
        parse_mode: 'Markdown',
      }),
    })
    
    const result = await response.text()
    console.log('Telegram response:', response.status, result.substring(0, 100))
    
    if (!response.ok) {
      console.error('Telegram API error:', response.status, result)
      return false
    }
    
    return true
  } catch (error) {
    console.error('Failed to send Telegram notification:', error)
    return false
  }
}

// Test Telegram connection
export async function testTelegramConnection(webhookUrl: string): Promise<{ success: boolean; message: string }> {
  if (!webhookUrl) {
    return { success: false, message: 'No webhook URL provided' }
  }
  
  // Validate URL format
  if (!webhookUrl.includes('api.telegram.org')) {
    return { success: false, message: 'Invalid URL. Must be api.telegram.org' }
  }
  
  try {
    const testMessage = '✅ Day Organizer connected successfully!\n\nYou will receive task reminders here.'
    
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: testMessage,
        parse_mode: 'Markdown',
      }),
    })
    
    if (response.ok) {
      return { success: true, message: 'Check your Telegram for a test message!' }
    } else {
      const error = await response.text()
      return { success: false, message: `Error: ${response.status}. Check your bot token and chat ID.` }
    }
  } catch (error) {
    return { success: false, message: 'Network error. Check your connection.' }
  }
}
